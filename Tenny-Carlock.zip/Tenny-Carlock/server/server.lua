-- Framework başlatılana kadar bekle
Citizen.CreateThread(function()
    while Config.Framework == nil do
        Citizen.Wait(100)
    end
    
    if Config.Debug then
        print('^2[Tenny-Carlock] ^7Server başlatıldı - Framework: ' .. Config.Framework .. '^7')
    end
end)

-- Araç sahiplik kontrolü için log sistemi
local function logVehicleLockAttempt(playerId, plate, success, reason)
    local xPlayer = Framework.GetPlayer(playerId)
    if xPlayer then
        local playerName = Framework.GetPlayerName(xPlayer)
        local playerIdentifier = Framework.GetPlayerIdentifier(xPlayer)
        print(string.format("^3[Tenny-Carlock] ^7Oyuncu: %s (%s) | Plaka: %s | Başarılı: %s | Sebep: %s^7", 
            playerName, playerIdentifier, plate, tostring(success), reason or "Yok"))
    end
end

-- Veritabanı tablosu belirleme (Framework uyumlu)
local function getVehicleTable()
    if Config.Framework == 'esx' then
        return "owned_vehicles"
    elseif Config.Framework == 'qb' or Config.Framework == 'qbx' then
        return "player_vehicles"
    end
    return "owned_vehicles"
end

-- Sahiplik sütunu belirleme (Framework uyumlu)
local function getOwnerColumn()
    if Config.Framework == 'esx' then
        return "owner"
    elseif Config.Framework == 'qb' or Config.Framework == 'qbx' then
        return "citizenid"
    end
    return "owner"
end

-- Araç sahibini kontrol et (Framework uyumlu)
local function registerCallback()
    if Config.Framework == 'esx' then
        Framework.ESX.RegisterServerCallback('exe-arackilit:isVehicleOwner', function(source, cb, plate)
            handleVehicleOwnerCheck(source, cb, plate)
        end)
    elseif Config.Framework == 'qb' or Config.Framework == 'qbx' then
        Framework.QBCore.Functions.CreateCallback('exe-arackilit:isVehicleOwner', function(source, cb, plate)
            handleVehicleOwnerCheck(source, cb, plate)
        end)
    end
end

-- Araç sahiplik kontrolü ana fonksiyonu
function handleVehicleOwnerCheck(source, cb, plate)
    local xPlayer = Framework.GetPlayer(source)
    
    if not xPlayer then
        cb(false)
        return
    end
    
    -- Plakayı temizle (boşlukları kaldır)
    local cleanPlate = string.gsub(plate, "%s+", "")
    
    -- Boş plaka kontrolü
    if not cleanPlate or cleanPlate == "" then
        logVehicleLockAttempt(source, plate, false, "Geçersiz plaka")
        cb(false)
        return
    end
    
    local vehicleTable = getVehicleTable()
    local ownerColumn = getOwnerColumn()
    local playerIdentifier = Framework.GetPlayerIdentifier(xPlayer)
    
    local query = string.format("SELECT * FROM %s WHERE REPLACE(plate, ' ', '') = ?", vehicleTable)
    local result = MySQL.query.await(query, { cleanPlate })
    
    if result[1] then
        local vehicleOwner = result[1][ownerColumn]
        if vehicleOwner == playerIdentifier then
            logVehicleLockAttempt(source, cleanPlate, true, "Araç sahibi")
            cb(true)
        else
            logVehicleLockAttempt(source, cleanPlate, false, "Araç sahibi değil")
            cb(false)
        end
    else
        -- Veritabanında bulunmayan araçlar kilitlenemez
        logVehicleLockAttempt(source, cleanPlate, false, "Araç veritabanında bulunamadı - sahipsiz araç")
        cb(false)
    end
end

-- Framework yüklendikten sonra callback'i kaydet
Citizen.CreateThread(function()
    while Config.Framework == nil do
        Citizen.Wait(100)
    end
    registerCallback()
end)
