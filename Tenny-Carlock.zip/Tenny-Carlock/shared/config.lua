Config = {}

-- Genel Ayarlar
Config.Debug = false -- Debug modunu açar/kapatır
Config.Locale = 'tr' -- Dil ayarı

-- Tuş Ayarları
Config.LockKey = 182 -- L tuşu (varsayılan)

-- Spam Engelleyici Ayarları
Config.NotifySpamDelay = 1500 -- Başarılı bildirimler arası süre (ms)
Config.ErrorSpamDelay = 3000 -- Hata bildirimleri arası süre (ms)
Config.ExitSpamDelay = 2000 -- Araçtan inme uyarısı arası süre (ms)

-- Araç Ayarları
Config.VehicleSearchDistance = 5.0 -- Yakındaki araç arama mesafesi
Config.LockAnimation = "anim@mp_player_intmenu@key_fob@" -- Kilit animasyonu
Config.AnimationDict = "fob_click" -- Animasyon adı

-- Bildirim Ayarları
Config.NotifyDuration = 3000 -- Bildirim süresi (ms)
Config.NotifyScript = 'tenny-notify' -- Kullanılacak bildirim scripti

-- Framework Ayarları (Otomatik algılanır)
Config.Framework = nil -- Otomatik algılanacak: 'esx' veya 'qb'