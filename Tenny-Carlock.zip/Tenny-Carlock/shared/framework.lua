-- Framework Algılama ve Uyumluluk Sistemi
Framework = {}

-- Framework algılama fonksiyonu
local function DetectFramework()
    if GetResourceState('es_extended') == 'started' then
        return 'esx'
    elseif GetResourceState('qb-core') == 'started' then
        return 'qb'
    elseif GetResourceState('qbx_core') == 'started' then
        return 'qbx'
    else
        return nil
    end
end

-- Framework başlatma
Citizen.CreateThread(function()
    local detectedFramework = DetectFramework()
    
    if detectedFramework == 'esx' then
        Config.Framework = 'esx'
        if IsDuplicityVersion() then -- Server tarafı
            Framework.ESX = exports['es_extended']:getSharedObject()
            print('^2[Tenny-Carlock] ^7ESX Framework tespit edildi^7')
        else -- Client tarafı
            Framework.ESX = exports['es_extended']:getSharedObject()
        end
        
    elseif detectedFramework == 'qb' then
        Config.Framework = 'qb'
        if IsDuplicityVersion() then -- Server tarafı
            Framework.QBCore = exports['qb-core']:GetCoreObject()
            print('^2[Tenny-Carlock] ^7QB-Core Framework tespit edildi^7')
        else -- Client tarafı
            Framework.QBCore = exports['qb-core']:GetCoreObject()
        end
        
    elseif detectedFramework == 'qbx' then
        Config.Framework = 'qbx'
        if IsDuplicityVersion() then -- Server tarafı
            Framework.QBX = exports.qbx_core
            print('^2[Tenny-Carlock] ^7QBX Framework tespit edildi^7')
        else -- Client tarafı
            Framework.QBX = exports.qbx_core
        end
        
    else
        Config.Framework = nil
        print('^1[Tenny-Carlock] ^7Desteklenen framework bulunamadı! (ESX/QB-Core/QBX gerekli)^7')
    end
end)

-- Oyuncu bilgisi alma (Framework uyumlu)
function Framework.GetPlayer(source)
    if Config.Framework == 'esx' then
        return Framework.ESX.GetPlayerFromId(source)
    elseif Config.Framework == 'qb' then
        return Framework.QBCore.Functions.GetPlayer(source)
    elseif Config.Framework == 'qbx' then
        return Framework.QBX:GetPlayer(source)
    end
    return nil
end

-- Oyuncu identifier alma (Framework uyumlu)
function Framework.GetPlayerIdentifier(xPlayer)
    if Config.Framework == 'esx' then
        return xPlayer.identifier
    elseif Config.Framework == 'qb' or Config.Framework == 'qbx' then
        return xPlayer.PlayerData.citizenid
    end
    return nil
end

-- Oyuncu grup/job alma (Framework uyumlu)
function Framework.GetPlayerGroup(xPlayer)
    if Config.Framework == 'esx' then
        return xPlayer.getGroup()
    elseif Config.Framework == 'qb' or Config.Framework == 'qbx' then
        return xPlayer.PlayerData.job.name == 'admin' and 'admin' or 'user'
    end
    return 'user'
end

-- Oyuncu adı alma (Framework uyumlu)
function Framework.GetPlayerName(xPlayer)
    if Config.Framework == 'esx' then
        return xPlayer.getName()
    elseif Config.Framework == 'qb' or Config.Framework == 'qbx' then
        return xPlayer.PlayerData.charinfo.firstname .. ' ' .. xPlayer.PlayerData.charinfo.lastname
    end
    return 'Bilinmeyen'
end

-- Bildirim gönderme (Framework uyumlu)
function Framework.Notify(source, type, title, message, duration)
    if Config.NotifyScript == 'tenny-notify' then
        TriggerClientEvent('tenny-notify:client:SendAlert', source, {
            type = type,
            text = message,
            length = duration or Config.NotifyDuration
        })
    elseif Config.Framework == 'esx' then
        TriggerClientEvent('esx:showNotification', source, message)
    elseif Config.Framework == 'qb' or Config.Framework == 'qbx' then
        TriggerClientEvent('QBCore:Notify', source, message, type)
    end
end