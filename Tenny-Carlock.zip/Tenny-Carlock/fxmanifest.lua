fx_version 'cerulean'
game 'gta5'

author 'Tenny'
description 'ESX/QBCore/QBX Uyumlu Araç Kilitleme Scripti - Otomatik Framework Algılama'
version '2.0.0'

shared_scripts {
    'shared/config.lua',
    'shared/framework.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/server.lua'
}

client_scripts {
    'client/client.lua'
}

lua54 'yes'
