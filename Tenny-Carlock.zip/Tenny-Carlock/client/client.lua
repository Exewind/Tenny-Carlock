-- Framework başlatılana kadar bekle
Citizen.CreateThread(function()
    while Config.Framework == nil do
        Citizen.Wait(100)
    end
    
    if Config.Debug then
        print('^2[exe-arackilit] ^7Client başlatıldı - Framework: ' .. Config.Framework .. '^7')
    end
end)

local isVehicleLocked = {}
local lastExitNotifyTime = 0 -- Araçtan inme bildirim spam engelleyici
local lastNotifyTime = 0 -- Bildirim spam engelleyici
local lastErrorNotifyTime = 0 -- Hata mesajı spam engelleyici

local function SendNotification(type, title, message)
    if Config.NotifyScript == 'tenny-notify' then
        if type == 'Success' then
            exports['tenny-notify']:Success(title, message, Config.NotifyDuration)
        elseif type == 'Error' then
            exports['tenny-notify']:Error(title, message, Config.NotifyDuration)
        elseif type == 'Warning' then
            exports['tenny-notify']:Warning(title, message, Config.NotifyDuration)
        elseif type == 'Info' then
            exports['tenny-notify']:Info(title, message, Config.NotifyDuration)
        end
    elseif Config.Framework == 'esx' then
        Framework.ESX.ShowNotification(message)
    elseif Config.Framework == 'qb' or Config.Framework == 'qbx' then
        Framework.QBCore.Functions.Notify(message, type)
    end
end

-- Server callback tetikleme (Framework uyumlu)
local function TriggerCallback(callbackName, callback, ...)
    if Config.Framework == 'esx' then
        Framework.ESX.TriggerServerCallback(callbackName, callback, ...)
    elseif Config.Framework == 'qb' or Config.Framework == 'qbx' then
        Framework.QBCore.Functions.TriggerCallback(callbackName, callback, ...)
    end
end

-- L tuşuna basıldığında araç kilitleme işlevi
Citizen.CreateThread(function()
    -- Framework yüklenmesini bekle
    while Config.Framework == nil do
        Citizen.Wait(100)
    end
    
    while true do
        Citizen.Wait(0) -- Responsive tuş algılama için

        if IsControlJustPressed(0, Config.LockKey) then -- L tuşu (config'den)
            local playerPed = PlayerPedId()
            local coords = GetEntityCoords(playerPed)
            local vehicle = GetVehiclePedIsIn(playerPed, false)

            -- Eğer araçta değilse yakındaki araca bak
            if vehicle == 0 then
                vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, Config.VehicleSearchDistance, 0, 71)
                if vehicle == 0 then
                    local currentTime = GetGameTimer()
                    if currentTime - lastErrorNotifyTime >= Config.ErrorSpamDelay then
                        SendNotification("Error", "Araç Kilidi", "Yakınlarda araç yok!")
                        lastErrorNotifyTime = currentTime
                    end
                    return
                end
            end

            local vehiclePlate = GetVehicleNumberPlateText(vehicle)
            
            -- Geçerli araç kontrolü
            if not DoesEntityExist(vehicle) then
                local currentTime = GetGameTimer()
                if currentTime - lastErrorNotifyTime >= Config.ErrorSpamDelay then
                    SendNotification("Error", "Araç Kilidi", "Geçerli bir araç bulunamadı!")
                    lastErrorNotifyTime = currentTime
                end
                return
            end

            -- Araç sahibi mi kontrol et
            TriggerCallback('exe-arackilit:isVehicleOwner', function(isOwner)
                if isOwner then
                    -- Kilit durumu değiştir
                    isVehicleLocked[vehiclePlate] = not isVehicleLocked[vehiclePlate]

                    -- Kilidi aç/kapa yap
                    if isVehicleLocked[vehiclePlate] then
                        SetVehicleDoorsLocked(vehicle, 2) -- Kilitle
                        PlayVehicleDoorCloseSound(vehicle, 1)
                        -- Bildirim spam kontrolü
                        local currentTime = GetGameTimer()
                        if currentTime - lastNotifyTime >= Config.NotifySpamDelay then
                            SendNotification("Success", "Araç Kilidi", "Araç kapıları kilitlendi.")
                            lastNotifyTime = currentTime
                        end
                    else
                        SetVehicleDoorsLocked(vehicle, 1) -- Aç
                        PlayVehicleDoorOpenSound(vehicle, 0)
                        -- Bildirim spam kontrolü
                        local currentTime = GetGameTimer()
                        if currentTime - lastNotifyTime >= Config.NotifySpamDelay then
                            SendNotification("Success", "Araç Kilidi", "Araç kapıları açıldı.")
                            lastNotifyTime = currentTime
                        end
                    end

                    -- Animasyon oynat
                    RequestAnimDict(Config.LockAnimation)
                    while not HasAnimDictLoaded(Config.LockAnimation) do
                        Citizen.Wait(100)
                    end
                    TaskPlayAnim(playerPed, Config.LockAnimation, Config.AnimationDict, 8.0, -8.0, 1500, 49, 0, false, false, false)

                else
                    local currentTime = GetGameTimer()
                    if currentTime - lastErrorNotifyTime >= Config.ErrorSpamDelay then
                        SendNotification("Error", "Araç Kilidi", "Bu araç size ait değil veya sahipsiz bir araç! Sadece satın aldığınız araçları kilitleyebilirsiniz.")
                        lastErrorNotifyTime = currentTime
                    end
                end
            end, vehiclePlate)
        end
    end
end)

-- **Araç kilitliyken çıkışı engelleme**
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0) -- Responsive çıkış engelleme için
        local playerPed = PlayerPedId()
        
        if IsPedInAnyVehicle(playerPed, false) then
            local vehicle = GetVehiclePedIsIn(playerPed, false)
            local vehiclePlate = GetVehicleNumberPlateText(vehicle)

            -- Eğer araç kilitliyse çıkışı engelle
            if isVehicleLocked[vehiclePlate] == true then
                -- Tüm çıkış tuşlarını devre dışı bırak
                DisableControlAction(0, 75, true)   -- F tuşu (Exit Vehicle)
                DisableControlAction(0, 23, true)   -- Enter tuşu (Exit Vehicle)
                DisableControlAction(0, 44, true)   -- Q tuşu (Cover)
                DisableControlAction(0, 322, true)  -- ESC tuşu
                
                -- Çıkış girişimi kontrolü
                if IsDisabledControlJustPressed(0, 75) or IsDisabledControlJustPressed(0, 23) then
                    -- Bildirim spam kontrolü
                    local currentTime = GetGameTimer()
                    if currentTime - lastExitNotifyTime >= Config.ExitSpamDelay then
                        SendNotification("Warning", "Araç Kilidi", "Araç kilitliyken inemezsiniz! Önce kilidi açın (L tuşu).")
                        lastExitNotifyTime = currentTime
                    end
                end
                
                -- Zorla araçta tut
                if not IsPedInVehicle(playerPed, vehicle, false) then
                    SetPedIntoVehicle(playerPed, vehicle, -1)
                end
            end
        end
    end
end)


