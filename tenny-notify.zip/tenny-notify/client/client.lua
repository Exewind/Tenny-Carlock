local function formatMoney(text)
    return string.gsub(text, "%$(%d+)", function(amount)
        local formatted = amount
        local k
        while true do
            formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1.%2')
            if k == 0 then
                break
            end
        end
        return '$' .. formatted
    end)
end

function Alert(type, title, message, duration, sound)
    local formattedTitle = formatMoney(title or 'Notification')
    local formattedMessage = formatMoney(message or '')
    
    SendNUIMessage({
        action = 'showNotification',
        type = type or 'info',
        title = formattedTitle,
        message = formattedMessage,
        duration = duration or 3000,
        sound = sound ~= false
    })
end

function Success(title, message, duration, sound)
    Alert('success', title, message, duration, sound)
end

function Error(title, message, duration, sound)
    Alert('error', title, message, duration, sound)
end

function Warning(title, message, duration, sound)
    Alert('warning', title, message, duration, sound)
end

function Info(title, message, duration, sound)
    Alert('info', title, message, duration, sound)
end

RegisterNetEvent('tenny-notify:Alert')
AddEventHandler('tenny-notify:Alert', function(type, title, message, duration)
    Alert(type, title, message, duration)
end)

RegisterNetEvent('tenny-notify:Success')
AddEventHandler('tenny-notify:Success', function(title, message, duration)
    Success(title, message, duration)
end)

RegisterNetEvent('tenny-notify:Error')
AddEventHandler('tenny-notify:Error', function(title, message, duration)
    Error(title, message, duration)
end)

RegisterNetEvent('tenny-notify:Warning')
AddEventHandler('tenny-notify:Warning', function(title, message, duration)
    Warning(title, message, duration)
end)

RegisterNetEvent('tenny-notify:Info')
AddEventHandler('tenny-notify:Info', function(title, message, duration)
    Info(title, message, duration)
end)

RegisterCommand("testnotify", function() 
    Success("Success", "Operation completed successfully!", 3000)
    Citizen.Wait(1000)
    Error("Error", "An error occurred!", 3000)
    Citizen.Wait(1000)
    Warning("Warning", "Attention required!", 3000)
    Citizen.Wait(1000)
    Info("Info", "Information message", 3000)
end, false)

RegisterCommand("testmoney", function() 
    Success("Money Test", "You earned: $1000000", 3000)
    Citizen.Wait(1000)
    Info("Balance", "Your current balance: $2500000", 3000)
    Citizen.Wait(1000)
    Warning("Warning", "$500000 withdrawn from your account", 3000)
    Citizen.Wait(1000)
    Error("Error", "$10000000 insufficient balance!", 3000)
end, false)