fx_version 'cerulean'
game 'gta5'

author 'Tenny'
description 'Tenny Modern Notification System'
version '2.0.0'

ui_page 'html/index.html'

client_scripts {
    'client/client.lua'
}

files {
    'html/*.*'
}

exports {
    'Alert',
    'Success',
    'Error',
    'Warning',
    'Info'
}