class TennyNotify {
    constructor() {
        this.container = document.getElementById('notification-container');
        this.notifications = new Map();
        this.notificationId = 0;
        this.soundEnabled = true;
        
        // Ses dosyasını preload et
        this.initSound();
        
        // Event listener for FiveM messages
        window.addEventListener('message', (event) => {
            if (event.data.action === 'showNotification') {
                this.show(event.data);
            }
        });
    }

    initSound() {
        try {
            this.notificationSound = document.getElementById('notification-sound');
            if (this.notificationSound) {
                this.soundEnabled = true;
            } else {
                this.soundEnabled = false;
            }
        } catch (error) {
            this.soundEnabled = false;
        }
    }

    show(data) {
        const id = ++this.notificationId;
        const notification = this.createNotification(id, data);
        
        this.container.appendChild(notification);
        this.notifications.set(id, notification);
        
        // Ses çal (eğer ses kapalı değilse)
        if (data.sound !== false) {
            this.playSound();
        }
        
        // Trigger show animation
        requestAnimationFrame(() => {
            notification.classList.add('show');
        });
        
        // Auto hide after duration
        if (data.duration && data.duration > 0) {
            this.startProgressBar(notification, data.duration);
            setTimeout(() => {
                this.hide(id);
            }, data.duration);
        }
        
        // Limit max notifications
        if (this.notifications.size > 5) {
            const firstId = this.notifications.keys().next().value;
            this.hide(firstId);
        }
    }

    playSound() {
        if (!this.soundEnabled || !this.notificationSound) {
            return;
        }
        
        try {
            this.notificationSound.currentTime = 0;
            this.notificationSound.play().catch(() => {
                // Sessizce başarısız ol
            });
        } catch (error) {
            // Sessizce başarısız ol
        }
    }

    createNotification(id, data) {
        const notification = document.createElement('div');
        notification.className = `notification ${data.type}`;
        notification.dataset.id = id;
        
        const icon = this.getIcon(data.type);
        
        notification.innerHTML = `
            <div class="notification-progress-left"></div>
            <div class="notification-content">
                <div class="notification-header">
                    <div class="notification-icon">${icon}</div>
                    <div class="notification-title">${data.title}</div>
                </div>
                ${data.message && data.message !== '' ? `<div class="notification-message">${data.message}</div>` : ''}
            </div>
        `;
        
        return notification;
    }

    getIcon(type) {
        const icons = {
            success: '✓',
            error: '✕',
            warning: '⚠',
            info: 'ℹ'
        };
        return icons[type] || icons.info;
    }

    startProgressBar(notification, duration) {
        const progressBar = notification.querySelector('.notification-progress-left');
        if (progressBar) {
            progressBar.style.animation = `shrinkVertical ${duration}ms linear forwards`;
        }
    }

    hide(id) {
        const notification = this.notifications.get(id);
        if (notification) {
            notification.classList.remove('show');
            notification.classList.add('hide');
            
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
                this.notifications.delete(id);
            }, 400);
        }
    }

    clear() {
        this.notifications.forEach((notification, id) => {
            this.hide(id);
        });
    }
}

const style = document.createElement('style');
style.textContent = `
    @keyframes shrinkVertical {
        from {
            transform: scaleY(1);
        }
        to {
            transform: scaleY(0);
        }
    }
`;
document.head.appendChild(style);

// Initialize notification system
const tennyNotify = new TennyNotify();

// Make it globally accessible for close buttons
window.tennyNotify = tennyNotify;