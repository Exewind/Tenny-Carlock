# 🔔 Tenny Notify

Modern ve şık FiveM bildirim sistemi | Modern and elegant FiveM notification system

![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)
![License](https://img.shields.io/badge/license-Custom-red.svg)
![Author](https://img.shields.io/badge/author-Tenny-purple.svg)

---

## 🇹🇷 Türkçe

### Özellikler
- 🎨 Modern ve şık tasarım
- 🔊 Bildirim sesi desteği
- 💰 Otomatik para formatı ($1000000 → $1.000.000)
- 🎯 4 farklı bildirim tipi (Success, Error, Warning, Info)
- 🚀 Hafif ve performanslı
- 📦 Export ve Event desteği

### Kurulum
1. `tenny-notify` klasörünü `resources` dizinine kopyalayın
2. `server.cfg` dosyanıza ekleyin:
```cfg
ensure tenny-notify
```
3. Sunucuyu yeniden başlatın

### Kullanım

**Export ile (Önerilen):**
```lua
-- Başarı bildirimi
exports['tenny-notify']:Success('Başarılı', 'İşlem tamamlandı!', 3000)

-- Hata bildirimi
exports['tenny-notify']:Error('Hata', 'Bir şeyler yanlış gitti!', 3000)

-- Uyarı bildirimi
exports['tenny-notify']:Warning('Uyarı', 'Dikkat gerekli!', 3000)

-- Bilgi bildirimi
exports['tenny-notify']:Info('Bilgi', 'Bilgilendirme mesajı', 3000)

-- Sessiz bildirim
exports['tenny-notify']:Success('Sessiz', 'Ses olmadan bildirim', 3000, false)
```

**Event ile:**
```lua
-- Client-side
TriggerEvent('tenny-notify:Success', 'Başarılı', 'İşlem tamamlandı!', 3000)
TriggerEvent('tenny-notify:Error', 'Hata', 'Bir şeyler yanlış gitti!', 3000)

-- Server-side
TriggerClientEvent('tenny-notify:Success', source, 'Başarılı', 'İşlem tamamlandı!', 3000)
```

### Parametreler
| Parametre | Tip | Açıklama | Varsayılan |
|-----------|-----|----------|------------|
| `type` | string | Bildirim tipi (success, error, warning, info) | info |
| `title` | string | Bildirim başlığı | Notification |
| `message` | string | Bildirim mesajı | - |
| `duration` | number | Gösterim süresi (milisaniye) | 3000 |
| `sound` | boolean | Ses çalsın mı? | true |

### Test Komutları
```
/testnotify    - Tüm bildirim tiplerini test et
/testmoney     - Para formatını test et
```

### ESX Entegrasyonu
```lua
ESX = exports['es_extended']:getSharedObject()

ESX.ShowNotification = function(msg, type, duration)
    if type == 'success' then
        exports['tenny-notify']:Success('Başarılı', msg, duration or 3000)
    elseif type == 'error' then
        exports['tenny-notify']:Error('Hata', msg, duration or 3000)
    else
        exports['tenny-notify']:Info('Bilgi', msg, duration or 3000)
    end
end
```

### QBCore Entegrasyonu
```lua
local QBCore = exports['qb-core']:GetCoreObject()

function QBCore.Functions.Notify(text, texttype, length)
    local type = texttype or 'info'
    local duration = length or 3000
    
    if type == 'success' then
        exports['tenny-notify']:Success('Başarılı', text, duration)
    elseif type == 'error' then
        exports['tenny-notify']:Error('Hata', text, duration)
    elseif type == 'warning' then
        exports['tenny-notify']:Warning('Uyarı', text, duration)
    else
        exports['tenny-notify']:Info('Bilgi', text, duration)
    end
end
```

---

## � 🇧 English

### Features
- 🎨 Modern and elegant design
- 🔊 Notification sound support
- 💰 Automatic money formatting ($1000000 → $1.000.000)
- 🎯 4 different notification types (Success, Error, Warning, Info)
- 🚀 Lightweight and performant
- 📦 Export and Event support

### Installation
1. Copy `tenny-notify` folder to your `resources` directory
2. Add to your `server.cfg`:
```cfg
ensure tenny-notify
```
3. Restart your server

### Usage

**With Exports (Recommended):**
```lua
-- Success notification
exports['tenny-notify']:Success('Success', 'Operation completed!', 3000)

-- Error notification
exports['tenny-notify']:Error('Error', 'Something went wrong!', 3000)

-- Warning notification
exports['tenny-notify']:Warning('Warning', 'Attention required!', 3000)

-- Info notification
exports['tenny-notify']:Info('Info', 'Information message', 3000)

-- Silent notification
exports['tenny-notify']:Success('Silent', 'Notification without sound', 3000, false)
```

**With Events:**
```lua
-- Client-side
TriggerEvent('tenny-notify:Success', 'Success', 'Operation completed!', 3000)
TriggerEvent('tenny-notify:Error', 'Error', 'Something went wrong!', 3000)

-- Server-side
TriggerClientEvent('tenny-notify:Success', source, 'Success', 'Operation completed!', 3000)
```

### Parameters
| Parameter | Type | Description | Default |
|-----------|------|-------------|---------|
| `type` | string | Notification type (success, error, warning, info) | info |
| `title` | string | Notification title | Notification |
| `message` | string | Notification message | - |
| `duration` | number | Display duration (milliseconds) | 3000 |
| `sound` | boolean | Play sound? | true |

### Test Commands
```
/testnotify    - Test all notification types
/testmoney     - Test money formatting
```

### ESX Integration
```lua
ESX = exports['es_extended']:getSharedObject()

ESX.ShowNotification = function(msg, type, duration)
    if type == 'success' then
        exports['tenny-notify']:Success('Success', msg, duration or 3000)
    elseif type == 'error' then
        exports['tenny-notify']:Error('Error', msg, duration or 3000)
    else
        exports['tenny-notify']:Info('Info', msg, duration or 3000)
    end
end
```

### QBCore Integration
```lua
local QBCore = exports['qb-core']:GetCoreObject()

function QBCore.Functions.Notify(text, texttype, length)
    local type = texttype or 'info'
    local duration = length or 3000
    
    if type == 'success' then
        exports['tenny-notify']:Success('Success', text, duration)
    elseif type == 'error' then
        exports['tenny-notify']:Error('Error', text, duration)
    elseif type == 'warning' then
        exports['tenny-notify']:Warning('Warning', text, duration)
    else
        exports['tenny-notify']:Info('Info', text, duration)
    end
end
```

---

## 📦 What's Inside?

```
tenny-notify/
├── client/
│   └── client.lua          # Client-side logic & exports
├── html/
│   ├── index.html          # NUI interface
│   ├── styles.css          # Modern styling
│   ├── script.js           # Notification system
│   └── notification.wav    # Sound effect
├── fxmanifest.lua          # Resource manifest
└── README.md               # This file
```

## 🎨 Notification Types

| Type | Color | Icon | Usage |
|------|-------|------|-------|
| **Success** | 🟢 Green | ✓ | Successful operations |
| **Error** | 🔴 Red | ✕ | Error situations |
| **Warning** | 🟠 Orange | ⚠ | Warning messages |
| **Info** | 🔵 Blue | ℹ | Informational messages |

## 📄 Lisans | License

### 🇹🇷 Türkçe
Bu script, **Tenny** tarafından oluşturulmuştur.

**Bu lisans altında:**
- ✅ Script ücretsiz olarak kullanılabilir
- ❌ Script ticari amaçla kullanılamaz veya satılamaz
- ❌ Script değiştirilemez veya türevleri oluşturulamaz
- ⚠️ Paylaşılması durumunda **Tenny**'nin adı belirtilmelidir

### 🇬🇧 English
This script was created by **Tenny**.

**Under this license:**
- ✅ Script can be used for free
- ❌ Script cannot be used commercially or sold
- ❌ Script cannot be modified or derivatives created
- ⚠️ If shared, **Tenny**'s name must be credited

## 👤 Author

**Tenny**

© 2024 Tenny - All Rights Reserved

---

<div align="center">

**Made with ❤️ for FiveM Community**

⭐ Star this repo if you like it!

</div>
